<?php
/**
 * Plugin Name:  Nomii AI Widget
 * Plugin URI:   https://pontensolutions.com
 * Description:  Embed your Nomii AI agent on any page or post with a shortcode or auto-embed. Configurable from Settings > Nomii AI.
 * Version:      1.0.0
 * Author:       Ponten Solutions
 * Author URI:   https://pontensolutions.com
 * License:      GPL-2.0+
 * Text Domain:  nomii-ai
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Prevent direct file access
}

define( 'NOMII_VERSION', '1.0.0' );
define( 'NOMII_OPTION_KEY', 'nomii_ai_settings' );

// ─── Settings page ────────────────────────────────────────────────────────────

add_action( 'admin_menu', 'nomii_add_settings_page' );
function nomii_add_settings_page() {
    add_options_page(
        'Nomii AI Settings',
        'Nomii AI',
        'manage_options',
        'nomii-ai',
        'nomii_render_settings_page'
    );
}

add_action( 'admin_init', 'nomii_register_settings' );
function nomii_register_settings() {
    register_setting( 'nomii_ai_settings_group', NOMII_OPTION_KEY, [
        'sanitize_callback' => 'nomii_sanitize_settings',
    ]);

    add_settings_section(
        'nomii_main_section',
        'Widget Configuration',
        '__return_null',
        'nomii-ai'
    );

    $fields = [
        'widget_key'      => [ 'Widget API Key',        'text',     'Paste your Nomii AI Widget Key here (found in your dashboard under Settings → Widget).' ],
        'api_url'         => [ 'API URL',                'url',      'Leave blank to use the default Nomii AI API (https://api.pontensolutions.com). Only change if you are self-hosting.' ],
        'auto_embed'      => [ 'Auto-embed on all pages', 'checkbox', 'If enabled, the widget loads on every page automatically. If disabled, use the [nomii_widget] shortcode on specific pages.' ],
        'position'        => [ 'Widget Position',        'select',   'Where the chat bubble appears on the screen.' ],
        'primary_color'   => [ 'Primary Color',          'color',    'The main color of the chat bubble and header. Should match your brand.' ],
        'secondary_color' => [ 'Accent Color',           'color',    'Accent color for highlights and buttons.' ],
        'greeting'        => [ 'Greeting Message',       'text',     'Optional: override the default greeting message shown to new visitors.' ],
    ];

    foreach ( $fields as $id => $config ) {
        add_settings_field(
            'nomii_' . $id,
            $config[0],
            'nomii_render_field',
            'nomii-ai',
            'nomii_main_section',
            [ 'id' => $id, 'type' => $config[1], 'desc' => $config[2] ]
        );
    }
}

function nomii_sanitize_settings( $input ) {
    $clean = [];
    $clean['widget_key']      = sanitize_text_field( $input['widget_key'] ?? '' );
    $clean['api_url']         = esc_url_raw( $input['api_url'] ?? '' );
    $clean['auto_embed']      = isset( $input['auto_embed'] ) ? '1' : '0';
    $clean['position']        = in_array( $input['position'] ?? '', [ 'bottom-right', 'bottom-left' ] )
                                  ? $input['position']
                                  : 'bottom-right';
    $clean['primary_color']   = sanitize_hex_color( $input['primary_color']   ?? '#1E3A5F' ) ?: '#1E3A5F';
    $clean['secondary_color'] = sanitize_hex_color( $input['secondary_color'] ?? '#C9A84C' ) ?: '#C9A84C';
    $clean['greeting']        = sanitize_text_field( $input['greeting'] ?? '' );
    return $clean;
}

function nomii_render_field( $args ) {
    $options = get_option( NOMII_OPTION_KEY, [] );
    $id      = $args['id'];
    $type    = $args['type'];
    $desc    = $args['desc'];
    $val     = $options[ $id ] ?? '';

    $name = NOMII_OPTION_KEY . '[' . esc_attr( $id ) . ']';

    if ( $type === 'checkbox' ) {
        printf(
            '<label><input type="checkbox" name="%s" value="1" %s /> Enabled</label>',
            esc_attr( $name ),
            checked( $val, '1', false )
        );
    } elseif ( $type === 'select' ) {
        $options_html = '';
        foreach ( [ 'bottom-right' => 'Bottom Right', 'bottom-left' => 'Bottom Left' ] as $opt_val => $opt_label ) {
            $options_html .= sprintf(
                '<option value="%s" %s>%s</option>',
                esc_attr( $opt_val ),
                selected( $val, $opt_val, false ),
                esc_html( $opt_label )
            );
        }
        printf( '<select name="%s">%s</select>', esc_attr( $name ), $options_html );
    } elseif ( $type === 'color' ) {
        $default = ( $id === 'primary_color' ) ? '#1E3A5F' : '#C9A84C';
        printf(
            '<input type="color" name="%s" value="%s" /> <code>%s</code>',
            esc_attr( $name ),
            esc_attr( $val ?: $default ),
            esc_html( $val ?: $default )
        );
    } else {
        printf(
            '<input type="%s" name="%s" value="%s" class="regular-text" />',
            esc_attr( $type ),
            esc_attr( $name ),
            esc_attr( $val )
        );
    }

    if ( $desc ) {
        printf( '<p class="description">%s</p>', esc_html( $desc ) );
    }
}

function nomii_render_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $opts = get_option( NOMII_OPTION_KEY, [] );
    ?>
    <div class="wrap">
        <h1 style="display:flex;align-items:center;gap:10px;">
            <span style="display:inline-block;background:#1E3A5F;color:#fff;border-radius:8px;padding:4px 12px;font-size:15px;font-weight:700;letter-spacing:0.5px;">Nomii AI</span>
            Widget Settings
        </h1>

        <?php if ( empty( $opts['widget_key'] ) ) : ?>
        <div class="notice notice-warning">
            <p><strong>Widget key not set.</strong> Paste your Nomii AI Widget Key below to activate the widget on your site. You can find it in your <a href="https://pontensolutions.com/nomii/dashboard" target="_blank">Nomii AI dashboard</a> under Settings → Widget.</p>
        </div>
        <?php endif; ?>

        <form method="post" action="options.php">
            <?php
            settings_fields( 'nomii_ai_settings_group' );
            do_settings_sections( 'nomii-ai' );
            submit_button( 'Save Settings' );
            ?>
        </form>

        <hr>
        <h2>Usage</h2>
        <h3>Option A — Shortcode (recommended for most sites)</h3>
        <p>Add <code>[nomii_widget]</code> to any page, post, or widget area where you want the chat bubble to appear.</p>
        <p>You can override settings per-page:</p>
        <pre style="background:#f0f0f1;padding:12px;border-radius:4px;font-size:13px;">[nomii_widget key="YOUR_KEY" position="bottom-left" primary_color="#1E3A5F"]</pre>

        <h3>Option B — Auto-embed</h3>
        <p>Enable <strong>Auto-embed on all pages</strong> above to load the widget sitewide without using shortcodes.</p>
    </div>
    <?php
}


// ─── Widget script injection ──────────────────────────────────────────────────

/**
 * Returns the resolved settings, optionally overridden by shortcode attributes.
 */
function nomii_get_config( $atts = [] ) {
    $saved = get_option( NOMII_OPTION_KEY, [] );

    return [
        'widget_key'      => ! empty( $atts['key'] )             ? sanitize_text_field( $atts['key'] )            : ( $saved['widget_key']      ?? '' ),
        'api_url'         => ! empty( $atts['api_url'] )          ? esc_url_raw( $atts['api_url'] )                : ( $saved['api_url']          ?? '' ),
        'position'        => ! empty( $atts['position'] )         ? sanitize_text_field( $atts['position'] )       : ( $saved['position']         ?? 'bottom-right' ),
        'primary_color'   => ! empty( $atts['primary_color'] )    ? sanitize_hex_color( $atts['primary_color'] )   : ( $saved['primary_color']    ?? '#1E3A5F' ),
        'secondary_color' => ! empty( $atts['secondary_color'] )  ? sanitize_hex_color( $atts['secondary_color'] ) : ( $saved['secondary_color']  ?? '#C9A84C' ),
        'greeting'        => ! empty( $atts['greeting'] )         ? sanitize_text_field( $atts['greeting'] )       : ( $saved['greeting']         ?? '' ),
    ];
}

/**
 * Outputs the widget embed script tag.
 */
function nomii_output_widget( $config ) {
    $key      = $config['widget_key'];
    if ( empty( $key ) ) return; // Nothing to render without a key

    $api_base = rtrim( $config['api_url'] ?: 'https://api.pontensolutions.com', '/' );
    $script   = esc_url( $api_base . '/embed.js' );
    $pos      = esc_attr( $config['position'] ?: 'bottom-right' );
    $primary  = esc_attr( $config['primary_color']   ?: '#1E3A5F' );
    $accent   = esc_attr( $config['secondary_color'] ?: '#C9A84C' );
    $greeting = esc_attr( $config['greeting'] );

    echo "\n<!-- Nomii AI Widget v" . NOMII_VERSION . " -->\n";
    echo '<script';
    echo ' src="' . $script . '"';
    echo ' data-widget-key="' . esc_attr( $key ) . '"';
    echo ' data-position="' . $pos . '"';
    echo ' data-primary-color="' . $primary . '"';
    echo ' data-secondary-color="' . $accent . '"';
    if ( $greeting ) echo ' data-greeting="' . $greeting . '"';
    echo ' defer></script>' . "\n";
}


// ─── Shortcode: [nomii_widget] ────────────────────────────────────────────────

add_shortcode( 'nomii_widget', 'nomii_shortcode_handler' );
function nomii_shortcode_handler( $atts ) {
    $atts   = shortcode_atts( [], $atts ?? [], 'nomii_widget' );
    $config = nomii_get_config( $atts );
    ob_start();
    nomii_output_widget( $config );
    return ob_get_clean();
}


// ─── Auto-embed (sitewide) ────────────────────────────────────────────────────

add_action( 'wp_footer', 'nomii_maybe_auto_embed' );
function nomii_maybe_auto_embed() {
    $opts = get_option( NOMII_OPTION_KEY, [] );
    if ( empty( $opts['auto_embed'] ) || $opts['auto_embed'] !== '1' ) return;

    // Don't double-inject if a shortcode already rendered it on this page
    if ( defined( 'NOMII_WIDGET_RENDERED' ) ) return;

    $config = nomii_get_config();
    nomii_output_widget( $config );
}

// Mark when shortcode has rendered to prevent duplicate injection
add_action( 'nomii_widget_rendered', function() {
    if ( ! defined( 'NOMII_WIDGET_RENDERED' ) ) define( 'NOMII_WIDGET_RENDERED', true );
});
