=== Nomii AI Widget ===
Contributors: pontensolutions
Tags: ai, chatbot, customer support, widget, live chat
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Embed your Nomii AI agent on any WordPress page or post with a simple shortcode or sitewide auto-embed.

== Description ==

Nomii AI is a personalized AI agent platform for businesses. This plugin lets you embed your Nomii AI chat widget on your WordPress site in seconds.

**Features:**
* Simple shortcode: `[nomii_widget]`
* Optional sitewide auto-embed (no shortcode needed)
* Configurable position, colors, and greeting
* Per-page shortcode overrides
* Lightweight — loads the widget script asynchronously, no tracking

**Getting started:**
1. Install and activate the plugin
2. Go to Settings → Nomii AI
3. Paste your Widget API Key (from your Nomii AI dashboard → Settings → Widget)
4. Add `[nomii_widget]` to any page, or enable Auto-embed for sitewide

== Installation ==

1. Upload the `nomii-ai` folder to `/wp-content/plugins/`
2. Activate the plugin through the WordPress Plugins screen
3. Go to Settings → Nomii AI and enter your Widget API Key

Or install via ZIP: Plugins → Add New → Upload Plugin → select `nomii-wordpress-plugin.zip`

== Frequently Asked Questions ==

= Where do I get my Widget API Key? =
Log in to your Nomii AI dashboard at pontensolutions.com, go to Settings → Widget, and copy your Widget Key.

= Can I use the widget on specific pages only? =
Yes. Leave Auto-embed disabled and add `[nomii_widget]` to only the pages you want.

= Can I override settings per page? =
Yes. The shortcode accepts attributes: `[nomii_widget key="..." position="bottom-left" primary_color="#1E3A5F"]`

= Is customer data stored in WordPress? =
No. All customer data is handled securely by the Nomii AI platform. This plugin only injects the widget script.

== Changelog ==

= 1.0.0 =
* Initial release
